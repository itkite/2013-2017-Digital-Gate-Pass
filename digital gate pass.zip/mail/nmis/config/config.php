 <?php

$server = "localhost"; //10.100.1.147
$username = "root"; //demo
$password = ""; //demo@123
$db_name = "cloudcoder";
$db_con = mysqli_connect("localhost",$username,$password,$db_name );

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
