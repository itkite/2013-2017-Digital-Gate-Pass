<?php
include('config/config.php');
include('config/connect-db.php');

session_start(); // start a session

$result = mysql_query(" SELECT id,username,firstname,phonenumber,email from cc_users ") or die(mysql_error());

include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- DataTables -->
 <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	 <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">  
	</head>

	<body class="no-skin">
		
			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs" id="breadcrumbs">
						<script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index_admin.php">Home</a>
							</li>

							
							<li class="active">Overall Chart</li>
						</ul><!-- /.breadcrumb -->

					<!--	<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>
<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
					<div class="page-content">
						

				<!--		<div class="page-header">
							<h1>
								Tables
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Static &amp; Dynamic Tables
								</small>
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
							
								



    <section class="content-header">
      <h1>
        Overall Details
        <small>CC MIS</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="morris.php">Charts</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
      <div class="row">
       <div class="col-md-12">
            <!-- LINE CHART -->
        <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Problems Chart</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="line-chart" style="height: 300px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- /.box -->

          

        </div></div>
        <!-- /.col (LEFT) -->
		<div class="row">
        <div class="col-md-6">
        
          <!-- DONUT CHART -->
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Statistics</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="sales-chart" style="height: 300px; position: relative;"></div>
            </div>
            <!-- /.box-body -->
          </div></div>
          <!-- /.box -->
          <!-- BAR CHART --><div class="col-md-6">
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Courses and Course Registrations</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="bar-chart" style="height: 300px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        
        <!-- /.col (RIGHT) -->
      </div></div>
    </div>
      </div>
     

    </section>
    <!-- /.content -->
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<h3  id="a" style="display:none;"><?php
$myfile = fopen("txt_files/sub_recipt.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("txt_files/sub_recipt.txt"));
fclose($myfile);
?></h3>
  <h3 id="b" style="display:none;">	<?php
$myfile = fopen("txt_files/tc_result.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("txt_files/tc_result.txt"));
fclose($myfile);
?></h3>
 <h3 id="c" style="display:none;"><?php
$myfile = fopen("txt_files/solved_problem.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("txt_files/solved_problem.txt"));
fclose($myfile);
?></h3>
 <h3 id="d" style="display:none;">	<?php
$myfile = fopen("txt_files/test_cases.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("txt_files/test_cases.txt"));
fclose($myfile);
?></h3>
  <h3 id="e" style="display:none;">		<?php
$myfile = fopen("txt_files/users.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("txt_files/users.txt"));
fclose($myfile);
?></h3>
<!-- Courses -->
<h3 id="ca"  style="display:none;">
<?php 
$qu="SELECT COUNT( * ) FROM  `cc_courses` WHERE YEAR =  '2013'";
$result=mysql_query($qu);
$r=mysql_fetch_assoc($result);
echo $r['COUNT( * )']; ?></h3>

<h3 id="cb"  style="display:none;">
<?php 

$qu="SELECT COUNT( * ) FROM  `cc_courses` WHERE YEAR =  '2014'";
$result=mysql_query($qu);
$r=mysql_fetch_assoc($result);
echo $r['COUNT( * )']; ?></h3>

<h3 id="cc"  style="display:none;">
<?php 

$qu="SELECT COUNT( * ) FROM  `cc_courses` WHERE YEAR =  '2015'";
$result=mysql_query($qu);
$r=mysql_fetch_assoc($result);
echo $r['COUNT( * )']; ?></h3>

<h3 id="cd"  style="display:none;">
<?php 

$qu="SELECT COUNT( * ) FROM  `cc_courses` WHERE YEAR =  '2016'";
$result=mysql_query($qu);
$r=mysql_fetch_assoc($result);
echo $r['COUNT( * )']; ?></h3>

<h3 id="ce"  style="display:none;">
<?php 

$qu="SELECT COUNT( * ) FROM  `cc_courses` WHERE YEAR =  '2017'";
$result=mysqli_query($qu);
$r=mysqli_fetch_assoc($result);
echo $r['COUNT( * )']; ?></h3>

<!-- Course Registrations -->
<h3 id="cra" style="display:none;">
<?php 

$qu="SELECT cc.user_id, cc.course_id, c.id, c.year
FROM cc_course_registrations cc, cc_courses c
WHERE cc.course_id = c.id
AND c.year =  '2013'";
$result=mysqli_query($qu);

echo mysqli_num_rows($result); ?></h3>

<h3 id="crb" style="display:none;">
<?php 

$qu="SELECT cc.user_id, cc.course_id, c.id, c.year
FROM cc_course_registrations cc, cc_courses c
WHERE cc.course_id = c.id
AND c.year =  '2014'";
$result=mysqli_query($qu);

echo mysqli_num_rows($result); ?></h3>

<h3 id="crc" style="display:none;">
<?php 

$qu="SELECT cc.user_id, cc.course_id, c.id, c.year
FROM cc_course_registrations cc, cc_courses c
WHERE cc.course_id = c.id
AND c.year =  '2015'";
$result=mysqli_query($qu);

echo mysqli_num_rows($result); ?></h3>

<h3 id="crd" style="display:none;">
<?php 

$qu="SELECT cc.user_id, cc.course_id, c.id, c.year
FROM cc_course_registrations cc, cc_courses c
WHERE cc.course_id = c.id
AND c.year =  '2016'";
$result=mysql_query($qu);

echo mysqli_num_rows($result); ?></h3>

<h3 id="cre" style="display:none;">
<?php 

$qu="SELECT cc.user_id, cc.course_id, c.id, c.year
FROM cc_course_registrations cc, cc_courses c
WHERE cc.course_id = c.id
AND c.year =  '2017'";
$result=mysqli_query($qu);

echo mysqli_num_rows($result); ?></h3>



<!-- Problem Count -->
<!-- 2013 -->
<h3 id="pc131" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2013-01-01 00:00:00'
                             AND '2013-04-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc132" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2013-04-01 00:00:00'
                             AND '2013-08-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc133" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2013-08-01 00:00:00'
                             AND '2013-12-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>



<!-- 2014 -->
<h3 id="pc141" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2014-01-01 00:00:00'
                             AND '2014-04-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysql_num_rows($qu); ?></h3>

<h3 id="pc142" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2014-04-01 00:00:00'
                             AND '2014-08-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc143" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2014-08-01 00:00:00'
                             AND '2014-12-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<!-- 2015 -->
<h3 id="pc151" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2015-01-01 00:00:00'
                             AND '2015-04-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc152" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2015-04-01 00:00:00'
                             AND '2015-08-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc153" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2015-08-01 00:00:00'
                             AND '2015-12-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<!-- 2016 -->
<h3 id="pc161" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2016-01-01 00:00:00'
                             AND '2016-04-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc162" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2016-04-01 00:00:00'
                             AND '2016-08-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc163" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2016-08-01 00:00:00'
                             AND '2016-12-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<!-- 2017 -->
<h3 id="pc171" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2017-01-01 00:00:00'
                             AND '2017-04-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc172" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2017-04-01 00:00:00'
                             AND '2017-08-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<h3 id="pc173" style="display:none;">
<?php 

$qu=mysqli_query($db_con,"SELECT FROM_UNIXTIME( `when_assigned` /1000 ) AS assign
                             FROM cc_problems
                             WHERE FROM_UNIXTIME( `when_assigned` /1000 )
                             BETWEEN '2017-08-01 00:00:00'
                             AND '2017-12-31 23:59:59'
                             GROUP BY assign
                             ORDER BY assign");
echo mysqli_num_rows($qu); ?></h3>

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    "use strict";

    // LINE CHART
	var pc1311=document.getElementById("pc131").innerHTML;
	var pc1321=document.getElementById("pc132").innerHTML;
	var pc1331=document.getElementById("pc133").innerHTML;
	var pc1411=document.getElementById("pc141").innerHTML;
	var pc1421=document.getElementById("pc142").innerHTML;
	var pc1431=document.getElementById("pc143").innerHTML;
	var pc1511=document.getElementById("pc151").innerHTML;
	var pc1521=document.getElementById("pc152").innerHTML;
	var pc1531=document.getElementById("pc153").innerHTML;
	var pc1611=document.getElementById("pc161").innerHTML;
	var pc1621=document.getElementById("pc162").innerHTML;
	var pc1631=document.getElementById("pc163").innerHTML;
	var pc1711=document.getElementById("pc171").innerHTML;
	var pc1721=document.getElementById("pc172").innerHTML;
	var pc1731=document.getElementById("pc173").innerHTML;
    var line = new Morris.Line({
      element: 'line-chart',
      resize: true,
      data: [
        {y: '2013 Q1', Problems: pc1311},
        {y: '2013 Q2', Problems: pc1321},
        {y: '2013 Q3', Problems: pc1331},
       
        {y: '2014 Q1', Problems: pc1411},
        {y: '2014 Q2', Problems: pc1421},
        {y: '2014 Q3', Problems: pc1431},
       
        {y: '2015 Q1', Problems: pc1511},
        {y: '2015 Q2', Problems: pc1521},
		{y: '2015 Q3', Problems: pc1531},
		
		{y: '2016 Q1', Problems: pc1611},
        {y: '2016 Q2', Problems: pc1621},
		{y: '2016 Q3', Problems: pc1631},
		
		{y: '2017 Q1', Problems: pc1711},
        {y: '2017 Q2', Problems: pc1721},
        {y: '2017 Q2', Problems: pc1721},
		{y: '2017 Q3', Problems: pc1731},
       
      ],
      xkey: 'y',
      ykeys: ['Problems'],
      labels: ['Preoblems'],
      lineColors: ['#3c8dbc'],
      hideHover: 'auto'
    });

    //STATISTICS
	var sr=document.getElementById("a").innerHTML;
	var tc=document.getElementById("b").innerHTML;
	var sp=document.getElementById("c").innerHTML;
	var cr=document.getElementById("d").innerHTML;
	var usr=document.getElementById("e").innerHTML;
	
    var donut = new Morris.Donut({
	
      element: 'sales-chart',
      resize: true,
      colors: ["#f56954", "#3c8dbc", "#e580ff" ,"red","#00a65a"],
      data: [
        {label: "Submission Receipts", value: sr},
        {label: "TestCase Results", value: tc},
        {label: "Problems", value: sp},
		{label: "Course Registrations", value: cr},
		{label: "Users", value: usr}
      ],
      hideHover: 'auto'
    });
    //BAR CHART
	var ca1=document.getElementById("ca").innerHTML;
	var cb1=document.getElementById("cb").innerHTML;
	var cc1=document.getElementById("cc").innerHTML;
	var cd1=document.getElementById("cd").innerHTML;
	var ce1=document.getElementById("ce").innerHTML;
	var cra1=document.getElementById("cra").innerHTML;
	var crb1=document.getElementById("crb").innerHTML;
	var crc1=document.getElementById("crc").innerHTML;
	var crd1=document.getElementById("crd").innerHTML;
	var cre1=document.getElementById("cre").innerHTML;
    var bar = new Morris.Bar({
      element: 'bar-chart',
      resize: true,
      data: [
        {y: '2013', a: ca1, b: cra1},
        {y: '2014', a: cb1, b: crb1},
        {y: '2015', a: cc1, b:crc1 },
        {y: '2016', a: cd1, b:crd1 },
        {y: '2017', a: ce1, b:cre1}
       
      ],
      barColors: ['#00a65a', '#f56954'],
      xkey: 'y',
      ykeys: ['a', 'b'],
      labels: ['Courses', 'Course Registrations'],
      hideHover: 'auto'
    });
  });
</script>

  <!-- /.content-wrapper -->
 <?php include('footer.php'); ?>
</body>
</html>
