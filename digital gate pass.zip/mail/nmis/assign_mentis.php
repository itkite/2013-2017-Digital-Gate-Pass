<?php
//This page for mentor to adding their mentis 
ini_set('error_reporting', 0);
include 'config/connect-db.php';
session_start();
$sql = "Select mentor_username,mentor_id from cc_mentors";
$result = mysql_query($sql);


$currentPage='asign_mentis';
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>

</head>

<body class="no-skin">

<div class="main-content">
	<div class="main-content-inner">
		<div class="breadcrumbs" id="breadcrumbs">
			<script type="text/javascript">
				try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
			</script>

			<ul class="breadcrumb">
				<li>
					<i class="ace-icon fa fa-home home-icon"></i>
					<a href="index_admin.php">Home</a>
				</li>

				<li class="active">Assign Mentees Here</li>
			</ul>
		</div>

		<div class="page-content">

			<div class="row">
				<div class="col-xs-12 col-sm-6">
					<!-- PAGE CONTENT BEGINS -->
					<div class="widget-box" style="width:1000px;padding-left:20px">
						<div class="widget-header">
							<h4 class="widget-title">Assign mentee</h4>
							<span class="widget-toolbar">
							
							</span>
						</div>

						<div class="widget-body">
							<div class="widget-main">
								<form action="" method="post" class="form-horizontal" role="form">

									<div class="form-group" ><br>
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Mentor Name  </label>
										<div class="col-sm-6">
											<select name="mentor_details" class="form-control select2" style="width: 50%;">

												<option value="">choose a mentor</option>
												<?php $mentor_id="";
												$mentor_username="";
												while ($row = mysql_fetch_array($result)) {

													$mentor_id=$row['mentor_id'];
													$mentor_username=$row['mentor_username'];
													?>

													<option value="<?php echo $mentor_id; ?>"><?php echo $mentor_username; ?></option>
												<?php } ?>

											</select>

										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Enter Username </label>

										<div class="col-sm-6">
											<select name="menti_details" class="form-control select2" style="width: 50%;"/>
											<option value="">Select Username</option>
											<?php
											$sql_users = "select id,username from cc_users where IsMentor='no'";
											$result_users = mysql_query($sql_users);
											$mentee_id="";
											$mantor_username="";
											while($row1=mysql_fetch_array($result_users)){
												$mentee_id	=	$row1['id'];
												$mentee_username =	$row1['username'];


												?>

												<option value="<?php echo $mentee_id; ?>"><?php echo $mentee_username; ?></option>
											<?php }  ?>
											</select>
										</div>

									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<input class="ace-icon fa fa-check bigger-110 btn btn-info" type="submit" name="submit" value="Add">




											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>
								</form>

								<?php
								if(isset($_POST['submit'])){	// As output of $_POST['mentor']  to display individual value

									$ment_id	= $_POST['mentor_details'];
									$mente_id	= $_POST['menti_details'];
									$q1=mysql_query("select * from cc_mentors where mentor_id='$ment_id'");
									$r1=mysql_fetch_array($q1);
									$mentor_username=$r1['mentor_username'];
									$q2=mysql_query("select * from cc_users where id='$mente_id'");
									$r2=mysql_fetch_array($q2);
									$mentee_username=$r2['username'];
									//echo $mentee_username;
									$check = "select * from cc_mentor_mentees where mentee_id='$mente_id'";

									$check_result=mysql_query($check);
									$row=mysql_fetch_array($check_result);
									$check_rows =mysql_num_rows($check_result);
									if($check_rows > 0)
									{
										//echo "exits already added";
										echo $check_rows;echo "<script type=\"text/javascript\">window.alert('  Mentee($mentee_username) Already assigned.');
												window.location.href = 'assign_mentis.php';</script>";
										exit;
									}
									else{
										$sql1= mysql_query("INSERT INTO `cc_mentor_mentees`( `mentor_id`, `mentor_username`, `mentee_id`, `mentee_username`, `date`, `time`, `add_by`)
												values ('".$ment_id."','".$mentor_username."','".$mente_id."','".$mentee_username."',curdate(),curtime(),'".$username."')");
										//$result1 = mysql_query($sql1);
										$row1 =mysql_num_rows($sql1);
										//echo $row1;
										//if($row1 == 1)
										//{
										echo "<script type=\"text/javascript\">window.alert('Mentee($mentee_username) assigned successfully.');
												window.location.href = 'assign_mentis.php';</script>";
										exit;
										//}

										//or die(mysql_error());
									}
								}

								//exit;
								?>
							</div>
						</div>

					</div><!-- widget-box -->
					<!--</div> /.col -->
				</div><!-- /.col -->
			</div><!-- /.row -->

		</div><!-- /.page-content -->
	</div>
</div><!-- /.main-content -->

<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">

</a>
</div><!-- /.main-container -->

<!-- footer -->

<?php include('footer.php'); ?>
</body>
</html>
