 <footer class="main-footer">
    
   <center> <strong>Copyright &copy;  <a href="http://ias.kgisl.com">KGiSL</a>.</strong> All rights
    reserved.</center>
  </footer>
