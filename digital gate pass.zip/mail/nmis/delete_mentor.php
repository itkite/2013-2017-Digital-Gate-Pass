<?php
include 'config/connect-db.php';
if(isset($_GET['id']))
{
$id=$_GET['id'];
$query=mysql_query("DELETE FROM `cc_mentors` WHERE mentor_id='$id'");
if($query){
$query1=mysql_query("update cc_users set IsMentor='no' where id='$id'");
if($query1)
{
header('location:cc_mentor_details.php');
}
}
}
?>