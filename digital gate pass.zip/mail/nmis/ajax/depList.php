<?php
session_start();
$_SESSION['depid']=$_POST['dlist'];
echo $_SESSION['depid'];
?>