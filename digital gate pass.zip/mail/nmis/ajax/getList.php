<?php
include('config.php');
session_start();
$_SESSION['pid']=$_POST['problemid'];


?>