<?php
include('../config/config.php');
session_start();
if(isset($_POST['courseid']))
{
$cid=$_POST['courseid'];
 $query2 = mysqli_query($db_con,"SELECT problem_id, testname FROM cc_problems WHERE course_id ='$cid'");
 ?>
 <option value="">Select Problem</option>
 <?php
 while ($row2 = mysqli_fetch_array($query2)) {
    if (!empty($_POST['problem_name']) && $row2['problem_id'] == $_POST['problem_name']) {
        $selected = "selected='selected'";
        } else {
                $selected = '';
               }
echo "<option " . $selected . " value=" . $row2['problem_id'] . ">" . $row2['testname'] . "</option>";
       }
}
?>