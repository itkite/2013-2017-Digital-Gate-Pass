<?php
include('../config/config.php');
if(isset($_POST['userid']))
{
$userId=$_POST['userid'];
$query ="SELECT course_id, title FROM cc_courses INNER JOIN (select * from cc_course_registrations where user_id = '" .$userId. "') AS cc ON cc_courses.id = cc.course_id";
	$results = mysqli_query($db_con,$query);
	
?>
	<option value="">Select Course</option>
<?php
	while($row=mysqli_fetch_array($results)){
	 if (!empty($_POST['course_name']) && $row1['course_id'] == $_POST['course_name']) {
                                                                    $selected = "selected='selected'";
                                                                } else {
                                                                    $selected = '';
                                                                }
	//echo $state['course_id'];
?>
	<option value="<?php echo $row['course_id']; ?>"><?php echo $row['title']; ?></option>
<?php
	}
}
?>
?>