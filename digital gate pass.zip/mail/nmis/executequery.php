 <?php
 ini_set('max_execution_time', 300); //300 seconds = 5 minutes
include('config/config.php');

	if(!empty($_POST['from_date'])) {
	$uid=$_POST['parameter'];
	$cid=$_POST['parameter1'];
	$pid=$_POST['parameter2'];
	$from = $_POST['from_date'];
	$to = $_POST['to_date'];
	
	
	/* $c=strtotime($a);
	$d=strtotime($b);
	$m = 1000;
	$from = $c * $m;
	$to = $d * $m;
	echo $from;
	echo $to;
	 */
	
	/*$search_query=mysqli_query($db_con,"select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,
	cc.name,cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,
	cc_users u,cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and 
	s.event_id=e.id and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id 
	and u.id='$uid'   order by event_id DESC limit 5");
	*/
$sqli1 = "";

/*	$sql=mysql_query("select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name,
		cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,cc_users u,
		cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and s.event_id=e.id 
		and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and p.course_id='$course_id' and e.problem_id='$problem_id' and e.timestamp>=unix_timestamp('{$from}') and e.timestamp<=unix_timestamp('{$to}')");  


$sql1=mysql_query("select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name,
		cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,cc_users u,
		cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and s.event_id=e.id 
		and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and p.course_id='$cid' and e.problem_id='$pid' and u.id='$uid'
		and e.timestamp>=unix_timestamp('{$from}') and e.timestamp<=unix_timestamp('{$to}'));		*/
		
		$where = "";
		if(!empty($uid)) {
			$where .= " AND u.id='{$uid}'";
		}
		if (!empty($cid)) {
			$where .= " AND p.course_id='{$cid}'";
		}
		if(!empty($pid)) {
			$where .= " AND p.problem_id='{$pid}'";
		}
		
		$sql = "select FROM_UNIXTIME(created_at) as ca, e.id,s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name, 	cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed,count(s.num_tests_attempted) as attempt,count(s.num_tests_passed) as passed
			from cc_events e
			left join cc_submission_receipts s on  s.event_id=e.id
			join cc_users u on u.id=e.user_id
			join cc_problems p on p.problem_id = e.problem_id
			join cc_courses cc on cc.id=p.course_id
			left join cc_terms t on t.id=cc.term_id
			WHERE DATE(FROM_UNIXTIME(e.timestamp/1000)) BETWEEN '{$from}' AND '{$to}' {$where} 
			group by p.testname
			order by e.timestamp desc
			limit 10"; 
			
			
			
		/* if(!empty($uid) && empty($cid) && empty($pid)) {
			

			$sqli1 = mysqli_query($db_con, $sql);
		}
		else if (!empty($uid) && !empty($cid) && empty($pid)) {
			$sql1 = "select e.id,s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name, cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed,count(s.num_tests_attempted) as attempt,count(s.num_tests_passed) as passed
			from cc_events e
			left join cc_submission_receipts s on  s.event_id=e.id
			left join cc_users u on  u.id=e.user_id
			left join cc_problems p on p.problem_id = e.problem_id
			left join cc_courses cc on cc.id=p.course_id
			left join cc_terms t on t.id=cc.term_id
			where  created_at<'{$to}' and created_at>'{$from}' and  u.id='$uid' 
			group by  p.testname
			order by e.timestamp desc
			limit 10";
			$sqli1=mysqli_query($db_con,$sql1);
		}
		else if(!empty($uid) && !empty($cid) && !empty($pid)) {
			$sql2 = "select e.id,s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name, cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed,count(s.num_tests_attempted) as attempt,count(s.num_tests_passed) as passed
			from cc_events e
			left join cc_submission_receipts s on  s.event_id=e.id
			left join cc_users u on  u.id=e.user_id
			left join cc_problems p on p.problem_id = e.problem_id
			left join cc_courses cc on cc.id=p.course_id
			left join cc_terms t on t.id=cc.term_id
			where u.id='$uid' and  p.course_id='$cid' and e.problem_id='$pid' and u.id='$uid' and left(e.timestamp,10) >='1326063600' and left(e.timestamp,10) <='1517785200') 
			group by  p.testname
			order by e.timestamp desc
			limit 10";
			$sqli1=mysqli_query($db_con, $sql2);
		

			/*select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name,
			cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,cc_users u,
			cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and s.event_id=e.id 
			and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and p.course_id='$cid' and e.problem_id='$pid' and u.id='$uid'
			and left(e.timestamp,10) >='$from_date' and left(e.timestamp,10) <='$to_date' limit 5"); 
		
		} */
		$sqli1 = mysqli_query($db_con,$sql);
		?>
	<div class="col-sm-12" style="margin:10px">
	<!-- PAGE CONTENT BEGINS -->
	<div class="widget-box">
	<div class="widget-header">
		<h4 class="widget-title"><b>Search Results</b></h4>

													<span class="widget-toolbar">
														<!--<a href="#" data-action="reload">
															<i class="ace-icon fa fa-refresh"></i>
														</a>-->
<?php	/* echo "select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name,
		cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,cc_users u,
		cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and s.event_id=e.id 
		and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and p.course_id='$cid' and e.problem_id='$pid' and u.id='$uid'
		and left(e.timestamp,10) >='$from_date' and left(e.timestamp,10) <='$to_date'"; exit; */  ?>


													</span>
	</div>

		<div class="widget-body">
			<div class="widget-main">
				<div class="row">
					<div class="col-xs-12">


						<div class="clearfix">
							<div class="pull-right tableTools-container"></div>
						</div>
						</div>
						<div>
						<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Search result</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
		<table id="dynamic-table" class="table table-striped table-bordered table-hover">
		<thead>

		<tr>
			<!--	<th>ID</th>	-->
			<th>Username</th>
			<th>Coursename</th>
			<th>Problem name</th>
			<th>Result</th>
			<!--	<th>Attempted Testcases</th>
                <th>Passed Testcases</th>-->

		</tr>

		</thead>

		<tbody>
		<?php
		while($row1 = mysqli_fetch_array($sqli1))
		{
		$attempted_tc=$row1['num_tests_attempted'];
		$passed_tc	=$row1['num_tests_passed'];
		$list_problem	=$row1['testname'];

		$problemLists=array($list_problem);
		$problemLists=array_unique($problemLists);

		for($j=1;$j<count($problemLists);$j++){

			$unique_problem=$problemLists[$j];
		}

		if(!$attempted_tc ==0 && !$passed_tc ==0){

			$maximum=max(array($attempted_tc));
			for ($i = 1; $i <count($maximum); $i++) {
				if ($a[$i] > $maximum) {
					$maximum = $a[$i];
				}
			}


$result = "";
			if($maximum==$passed_tc){
				$result="Passed";
			}	}
		else{
			$result="Attempted";
		}


		?> 
		<tr>
			<td><?php echo $row1['username']; ?></td>

			<td><?php echo $row1['title']; ?></td>

			<td><a href="http://cloudcoder.kgkite.ac.in/cloudcoder/#submissions?c=<?php echo $cid; ?>,p=<?php echo $pid; ?>,u=<?php echo $uid; ?>" target="_blank"><?php echo $row1['testname'];?></a></td>
			<?php if ($result=="Attempted"){?>
			<td><?php echo "<font color='Orange'>$result.($attempted_tc)</font>"; }else{?></td>

			<td><?php echo "<font color='#18B827'>$result</font>"; }?></td>
		</tr>
			<?php }  ?>
			
		</tbody>
	</table>
	</div>
	</div>
	</div>
	</div>
	</section>
	<?php
}
else
{
	//echo "<script>alert('Select all the fields');</script>";
	 echo '  
       <div class="col-sm-12">  <div class="pull-right tableTools-container"></div>
    </div>
	<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Search Results</h3>
            </div>
  <div class="box-body"><table id="dynamic-table" class="table table-striped table-bordered table-hover">
	 <thead>
        <tr>
           <th>Username</th>
			<th>Coursename</th>
			<th>Problem name</th>
			<th>Result</th>
        </tr>
        </thead></table>
		</div>
	</div>
	</div>
	</div></section></div>
	';
}
//include('footer.php');
?>
