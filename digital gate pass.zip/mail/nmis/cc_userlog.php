<?php
ini_set('error_reporting', 0);
include('config/connect-db.php');
session_start(); // start a session
if (isset($_SESSION['SESS_FIRST_NAME'])) { 	   // check if session user_id is set
	$username = $_SESSION['SESS_FIRST_NAME']; //if it is set, assign the value to the variable $userid
}
else { // if it is not set
	$username = ""; // assign a null value to $userid
}

include('header.php');
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- DataTables -->
 <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	 <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">  
	</head>

	<body class="no-skin">
		
			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs" id="breadcrumbs">
						<script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="index_admin.php">Home</a>
							</li>

							
							<li class="active">User log</li>
						</ul><!-- /.breadcrumb -->

					<!--	<div class="nav-search" id="nav-search">
							<form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
							</form>
						</div><!-- /.nav-search -->
					</div>

					<div class="page-content">
						

				<!--		<div class="page-header">
							<h1>
								Tables
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Static &amp; Dynamic Tables
								</small>
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
							
								<div class="row">
									<div class="col-xs-12">
										

										<div class="clearfix">
											<div class="pull-right tableTools-container"></div>
										</div>
										
										<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">User log Details</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
	<table id="dynamic-table" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														
														<th>User name</th>
														<th>Login Date</th>
														
														<th class="hidden-480">Logout Date</th>

														
													</tr>
												</thead>

												<tbody>
<?php
//include('db_connection.php');
//include_once('db_connection.php');

$sql = " SELECT user_log_id,username,login_date ,logout_date from user_log";
$result = mysql_query($sql) or die(mysql_error()); 
//echo $result;
If (mysql_num_rows($result) > 0) {
    while ($row = mysql_fetch_array($result)) {
?>
													<tr>
														
														<td>
															<?php echo $row['username'];?>
														</td>
														<td>
															<?php echo $row['login_date'];?>
														</td>
														<td class="hidden-480">
															<?php echo $row['logout_date']; ?>
														</td>
														
														

							<!--</tr>	-->						
														
														
													<!--	<td class="hidden-480">
															<span class="label label-sm label-warning">Expiring</span>
														</td>-->
														
									

								
													</tr>
													
													
														<?php
														
	}
}
?>

													
												</tbody>
											</table>
										</div>
	</div>
	</div>
	</div>
	</section>
								<!--	<h4 class="pink">
									<i class="ace-icon fa fa-hand-o-right icon-animated-hand-pointer blue"></i>
									<a href="#modal-table" role="button" class="green" data-toggle="modal"> Table Inside a Modal Box </a>
								</h4>-->
									
								</div>
								
								
</div></div></div></div></div>

		<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
		<script src="assets/js/jquery.dataTables.min.js"></script>
		<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
		<script src="assets/js/dataTables.tableTools.min.js"></script>
		<script src="assets/js/dataTables.colVis.min.js"></script>
<script src="datat.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->

</form></div></div>
<?php include('footer.php'); ?>
  </body>
    </html>
