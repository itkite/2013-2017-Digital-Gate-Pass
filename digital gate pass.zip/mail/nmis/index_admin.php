<?php


$currentPage = 'search_user';
session_start();
include('header.php');
include('config/config.php');
?>
    <html>
    <head>
     <!-- DataTables -->

	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
      
        <script>
            function getCourse(val) {
                //var user=$("#user-list").val();
                $.ajax({
                    type: "POST",
                    url: "ajax/getCourse.php",
                    data: 'userid=' + val,
                    success: function (data) {
                        //alert(data);
						$('#course_list').html(data);
                    }
                });
            }
            function getProblem(val) {
                $.ajax({
                    type: "POST",
                    url: "ajax/getProblem.php",
                    data: "courseid=" + val,
                    success: function (data) {
                        //alert(data);
						$('#problem_list').html(data);
                    }
                });
            }
            function getList(val) {
                /* $.ajax({
                    method: "POST",
                    url: "ajax/getList.php",
                    data: "problemid=" + val,
                    success: function (data) {
                        //alert(data);
                    }
                });  */
            }
			$("body").on("click","#aa",function(){
			 $("#wait").css("display", "block");
				var query_parameter = document.getElementById("user-list").value;
			
			
				var query_parameter1 = document.getElementById("course_list").value;
				var query_parameter2 = document.getElementById("problem_list").value;
				//var dataString = 'parameter=' + query_parameter + '&parameter1=' +query_parameter1+ '&parameter2=' + query_parameter2+ '&from_date=' + $("[name='from']").val()+'&to_date='+$("[name='to']").val();
				var dataString = { 
									
									'parameter': query_parameter,  
									'parameter1': query_parameter1, 
									'parameter2': query_parameter2, 
								
								};

				// AJAX code to execute query and get back to same page with table content without reloading the page.
				//alert(1);
				$.ajax({
				type: "POST",
				url: "exequery.php",
				data: dataString,
				cache: false,
				success: function(html) {
				//window.location.reload(false);
				// alert(dataString);
				document.getElementById("table_content").innerHTML=html;
				
				//alert(html);
				console.log(html);
				 $("#wait").css("display", "none");
				return false;
				}
				
				});
				return false;
			});
        </script>
        <style>
            .a {
                padding-top: 30px;
            }
        </style>
    </head>
    <body>

    <form method="post" class="form-horizontal">
        <div class="main-content">
            <div class="main-content-inner">
			<div class="breadcrumbs" id="breadcrumbs">
			<script type="text/javascript">
				try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
			</script>

			<ul class="breadcrumb">
				<li>
					<i class="ace-icon fa fa-home home-icon"></i>
					<a href="index_admin.php">Home</a>
				</li>

				<li class="active">Dashboard</li>
			</ul>
		</div>
                <div class="page-content">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <div class="alert alert-block alert-success">
                                <button type="button" class="close" data-dismiss="alert">
                                    <i class="ace-icon fa fa-times"></i></button>
                                <i class="ace-icon fa fa-check green"></i>Welcome to
                                <strong class="green">
                                    KG Cloud Coder Admin Page
                                </strong>
                            </div>
                            <!--here for the change-->
                            <div class="col-sm-12">
                              <br><br>
                                            <div class="row ">
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label no-padding-right">Select
                                                        Username</label>
                                                    <div class="col-sm-6">
                                                        <select name="username"  class="form-control select2" style="width: 50%;" id="user-list" onChange="getCourse(this.value);">
                                                            <option value="">Select Username</option>
                                                            <?php
                                                            $query = mysqli_query($db_con,"select * from cc_users");
                                                            while ($row = mysqli_fetch_array($query)) {
                                                                $selected = "";
                                                                echo "<option " . $selected . " value=" . $row['id'] . ">" . $row['username'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label no-padding-right">Select
                                                        Course</label>
                                                    <div class="col-sm-6">
                                                        <select name="course_name" id="course_list" class="form-control select2" style="width: 50%;"
                                                                onchange="getProblem(this.value)">
                                                            <option value="">Select Course</option>
                                                            <?php
                                                            $query = mysqli_query($db_con,"select * from cc_courses");
                                                            while ($row = mysqli_fetch_array($query)) {
                                                                
                                                                echo "<option " . $selected . " value=" . $row['id'] . ">" . $row['name'] . "</option>";
                                                            }
															
															
                                                          /*  $query1 = mysql_query("SELECT course_id, title FROM cc_courses INNER JOIN
		                                                                          (select * from cc_course_registrations where user_id = '" . $_SESSION['uid'] . "') AS
		                                                                          cc ON cc_courses.id = cc.course_id");
                                                            while ($row1 = mysql_fetch_array($query1)) {
                                                                if (!empty($_POST['course_name']) && $row1['course_id'] == $_POST['course_name']) {
                                                                    $selected = "selected='selected'";
                                                                } else {
                                                                    $selected = '';
                                                                }
                                                                echo "<option " . $selected . " value=" . $row1['course_id'] . ">" . $row1['title'] . "</option>";
                                                            }	*/
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label no-padding-right">Select
                                                        Problem</label>
                                                    <div class="col-sm-6">
                                                        <select name="problem_name" id="problem_list" class="form-control select2" style="width: 50%;"
                                                                onchange="getList(this.value)">
                                                            <option value="">Select Problem</option>
                                                            <?php
                                                            $query = mysqli_query($db_con,"select * from cc_courses");
                                                            while ($row = mysqli_fetch_array($query)) {
                                                                
                                                                echo "<option " . $selected . " value=" . $row['id'] . ">" . $row['title'] . "</option>";
                                                            }
															
															
															
															
                                                        /*    $query2 = mysql_query("SELECT problem_id, testname FROM cc_problems WHERE course_id =" . $_SESSION['cid']);
                                                            while ($row2 = mysql_fetch_array($query2)) {
                                                                if (!empty($_POST['problem_name']) && $row2['problem_id'] == $_POST['problem_name']) {
                                                                    $selected = "selected='selected'";
                                                                } else {
                                                                    $selected = '';
                                                                }
                                                                echo "<option " . $selected . " value=" . $row2['problem_id'] . ">" . $row2['testname'] . "</option>";
                                                            }	*/
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>

										<div class="col-md-offset-3 col-md-4">
											
												<button type="button" class="btn btn-info" id="aa"> Search  <span class="glyphicon glyphicon-search"></span></button>
											
											
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>


										</div>	
                                            </div>
											<div id="wait" style="display:none;width:69px;height:89px;position:absolute;top:50%;left:50%;padding:2px;"><img src='https://loading.io/spinners/microsoft/lg.rotating-balls-spinner.gif' width="80" height="80" /><br>Loading..</div>
											<div id="table_content"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </form>
  

</div>
</div>
<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="assets/js/jquery.dataTables.min.js"></script>
		<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
		<script src="assets/js/dataTables.tableTools.min.js"></script>
		<script src="assets/js/dataTables.colVis.min.js"></script>
<script src="datat.js"></script><!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->

  </body>
    </html>