<?php
ini_set('error_reporting', 0);
include('config/connect-db.php');
session_start();
include('header.php');
$sql = "select * from cc_mentors";
$result = mysql_query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- DataTables -->

	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
</head>
<body>
<div class="main-content">
	<div class="main-content-inner">
		<div class="breadcrumbs" id="breadcrumbs">
			<script type="text/javascript">
				try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
			</script>

			<ul class="breadcrumb">
				<li>
					<i class="ace-icon fa fa-home home-icon"></i>
					<a href="index_admin.php">Home</a>
				</li>


				<li class="active">Mentor Details</li>
			</ul><!-- /.breadcrumb -->

			<!-- /.nav-search -->
		</div>
		<div class="page-content">



			<div class="row">
				<div class="col-xs-12 col-sm-7">
					<!-- PAGE CONTENT BEGINS -->
					<div class="widget-box" style="width:1000px;padding-left:20px">
						<div class="widget-header">
							<h4 class="widget-title">View mentor & mentee Information</h4>

													<span class="widget-toolbar">


														<a href="#" data-action="collapse">
															<i class=""></i>
														</a>


													</span>
						</div><br>
						<div class="row" style="padding-left:20px">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->

								<div class="row">
									<div class="col-xs-12">
										<div class="clearfix">
											<form action="" method="post" class="form-horizontal" role="form">


												<label class="col-xs-2">Select mentor </label>

												<select name="mentor_uname"  class="form-control select2 col-xs-4" style="width: 20%;">
													<option value="">choose a mentor</option>
													<?php while ($row = mysql_fetch_array($result)) {

														$mentor_username=$row['mentor_username'];
														$mentor_id = $row['mentor_id'];
														if(!empty($_POST['mentor_uname']) && $row['mentor_id']==$_POST['mentor_uname'])
														{
															$selected="selected='selected'";
														}
														else
														{
															$selected='';
														}

														?>
														<option value="<?php echo $mentor_id;?>" <?php echo $selected; ?>><?php echo $mentor_username;?></option>

													<?php } ?>
												</select>
												&nbsp;&nbsp;
												<!--<div class="col-md-offset-3 col-md-9">-->
												<button class="btn btn-primary" style="margin-left:10px type="submit" name="submit">
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
												</button>
												<!--</div>	-->
										</div>
										</form>

										<?php
										if(isset($_POST['submit'])){
										// As output of $_POST['mentor']  to display individual value

										$mentor_id 	= $_POST['mentor_uname'];

										//echo "You have selected :" .$select;  Displaying Selected Value
										//SELECT b.mentee_username,a.firstname,a.email from cc_users a,cc_mentor_mentees b where b.mentor_id='36' and b.mentee_username=a.username
										$sql1 = mysql_query("SELECT b.mentee_username,a.firstname,a.phonenumber,a.email from cc_users a,cc_mentor_mentees b where b.mentor_id='$mentor_id' and a.id='$mentor_id'");

										$s=mysql_query("select * from cc_mentors where mentor_id='$mentor_id'");
										$q=mysql_fetch_array($s);
										?>

										<br><br>

										<!--table here-->
										<div class="row">
											<div class="col-xs-12">


												<div class="clearfix">
													<div class="pull-right tableTools-container"></div>
												</div>


												<!-- div.table-responsive -->

												<!-- div.dataTables_borderWrap -->
												<div class="row">
													<div class="col-xs-12">
														<div class="box">
															<div class="box-header">
																<h3 class="box-title"><i class="ace-icon fa fa-search nav-search-icon"></i>
																	Mentees Under the <?php echo $q['mentor_username'];?></h3>
															</div>
															<!-- /.box-header -->
															<div class="box-body">
																<table id="dynamic-table" class="table table-striped table-bordered table-hover">
																	<thead>


																	<tr>

																		<th>Mentee Username</th>
																		<th>Mentor Name</th>
																		<th>Mentor PhoneNumber</th>
																		<th>Mentor Email</th>
																		<!--		<th>Enable Email</th>
                                                                    <th>Time</th>-->


																	</tr>
																	</thead>

																	<tbody>
																	<?php while($row=mysql_fetch_array($sql1))
																	{
																		?>
																		<tr>
																			<td><?php echo $row['mentee_username']; ?></td>

																			<td><?php echo $row['firstname']; ?></td>

																			<td><?php echo $row['phonenumber']; ?></td>

																			<td><?php echo $row['email']; ?></td>


																			<!--	<td><a href="enable_email.php">Yes</a></td> -->


																		</tr>


																		<?php
																	}

																	?>
																	</tbody>
																</table>
															</div>
														</div>


													</div>								</div>

											</div>
											<?php }
											else{
												echo '
       <div class="col-sm-12">  <div class="pull-right tableTools-container"></div>
    </div>
	<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Search Results</h3>
            </div>
  <div class="box-body"><table id="dynamic-table" class="table table-striped table-bordered table-hover">
	 <thead>
        <tr>
            <th>Mentee Username</th>
		    <th>Mentor Name</th>
			<th>Mentor PhoneNumber</th>
			<th>Mentor Email</th>
        </tr>
        </thead></table>
		</div>
	</div>
	</div>
	</div>
	</section>
	</div></div>
	</div></div>
	</div></div>
	</div></div>
	</div></div>
	
	
	</div>';
											}
											include('footer.php');
											?>

											<!-- jQuery 2.2.3 -->
											<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
											<!-- Bootstrap 3.3.6 -->
											<script src="bootstrap/js/bootstrap.min.js"></script>
											<script src="assets/js/jquery.dataTables.min.js"></script>
											<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
											<script src="assets/js/dataTables.tableTools.min.js"></script>
											<script src="assets/js/dataTables.colVis.min.js"></script>
											<script src="datat.js"></script>

											<!-- SlimScroll -->
											<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
											<!-- FastClick -->
											<script src="plugins/fastclick/fastclick.js"></script>
											<!-- AdminLTE App -->
											<script src="dist/js/app.min.js"></script>
											<!-- AdminLTE for demo purposes -->
											<script src="dist/js/demo.js"></script>
											<!-- page script -->


</body>
</html>
