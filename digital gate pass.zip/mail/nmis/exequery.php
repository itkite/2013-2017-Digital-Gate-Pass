<?php
include('config/config.php');


if (isset($_POST['parameter'])) {
    $uid=$_POST['parameter'];
	$cid=$_POST['parameter1'];
	$pid=$_POST['parameter2'];
	
	
	
   /* $query = mysqli_query($db_con,"select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,
	cc.name,cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,
	cc_users u,cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and 
	s.event_id=e.id and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and cc.id ='$cid'
	and u.id='$uid' and e.problem_id='$pid' order by event_id DESC limit 1");  */
	

		$where = "";
		if(!empty($uid)) {
			$where .= !empty($where) ? " AND u.id='{$uid}' " : " u.id='{$uid}' ";
		}
		if (!empty($cid)) {
			$where .= !empty($where) ? " AND p.course_id='{$cid}'" : " p.course_id='{$cid}' ";
		}
		if(!empty($pid)) {
			$where .= !empty($where) ? " AND p.problem_id='{$pid}'" : " p.problem_id='{$pid}'";
		}
		
		$where = empty($where) ? "" : "WHERE ".$where;
	
		$sql = "select e.id,s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,cc.name, cc.title,u.email,t.name,cc.year, s.num_tests_attempted,s.num_tests_passed,count(s.num_tests_attempted) as attempt,count(s.num_tests_passed) as passed
			from cc_events e
			left join cc_submission_receipts s on  s.event_id=e.id
			join cc_users u on u.id=e.user_id
			join cc_problems p on p.problem_id = e.problem_id
			join cc_courses cc on cc.id=p.course_id
			left join cc_terms t on t.id=cc.term_id $where
			group by p.testname
			order by e.timestamp desc
			limit 10"; 
		
		$qry = mysqli_query($db_con,$sql);
	
	
	/*select s.event_id,e.user_id,u.username,e.problem_id,p.course_id,p.testname,
	cc.name,cc.title,u.email,cc.year, s.num_tests_attempted,s.num_tests_passed from cc_events e,
	cc_users u,cc_submission_receipts s,cc_courses cc,cc_problems p,cc_terms t where cc.id =p.course_id and 
	s.event_id=e.id and u.id=e.user_id and e.problem_id=p.problem_id and t.id=cc.term_id and cc.id ='$cid'
	and u.id='$uid' and e.problem_id='$pid' order by event_id DESC limit 1 */
    ?>
    <div class="col-sm-12">
    <!-- PAGE CONTENT BEGINS -->
    
        <div class="pull-right tableTools-container"></div>
    </div>
	<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Search Results</h3>
            </div>
  <div class="box-body">
       <table id="dynamic-table" class="table table-striped table-bordered table-hover">
        <thead>
        <tr>
            <th>Username</th>
            <th>Coursename</th>
            <th>Problem name</th>
            
        </tr>
        </thead>
        <tbody>
        <?php
        while ($row1 = mysqli_fetch_array($qry))
        {
        ?>
        <tr>
            <td><?php echo $row1['username']; ?></td>
            <td><?php echo $row1['title']; ?></td>
            <td><a href="http://cloudcoder.kgkite.ac.in/cloudcoder/#submissions?c=<?php echo $cid; ?>,p=<?php echo $pid; ?>,u=<?php echo $uid; ?>" target="_blank"><?php echo $row1['testname']; ?></a></td>
            
        <tr>
            <?php } ?>
        </tbody>
    </table></div>
	</div>
	</div>
	</div>
	</section></div>
    <?php
} else {
    echo '  
       <div class="col-sm-12">  <div class="pull-right tableTools-container"></div>
    </div>
	<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Search Results</h3>
            </div>
  <div class="box-body"><table id="dynamic-table" class="table table-striped table-bordered table-hover">
	 <thead>
        <tr>
            <th>Username</th>
            <th>Coursename</th>
            <th>Problem name</th>
            
			
        </tr>
        </thead></table>
		</div>
	</div>
	</div>
	</div>
	</section></div>';
}
include('footer.php');
?>