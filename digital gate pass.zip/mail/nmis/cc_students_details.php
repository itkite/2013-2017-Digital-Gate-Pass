<?php
include('config/config.php');
include('config/connect-db.php');

session_start(); // start a session

$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' ") or die(mysql_error());

include('header.php');
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<!-- DataTables -->
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
</head>

<body class="no-skin">

<div class="main-content">
	<div class="main-content-inner">
		<div class="breadcrumbs" id="breadcrumbs">
			<script type="text/javascript">
				try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
			</script>

			<ul class="breadcrumb">
				<li>
					<i class="ace-icon fa fa-home home-icon"></i>
					<a href="index_admin.php">Home</a>
				</li>


				<li class="active">Student details</li>
			</ul><!-- /.breadcrumb -->

			<!--	<div class="nav-search" id="nav-search">
                    <form class="form-search">
                        <span class="input-icon">
                            <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                            <i class="ace-icon fa fa-search nav-search-icon"></i>
                        </span>
                    </form>
                </div><!-- /.nav-search -->
		</div>

		<div class="page-content">


			<!--		<div class="page-header">
                        <h1>
                            Tables
                            <small>
                                <i class="ace-icon fa fa-angle-double-right"></i>
                                Static &amp; Dynamic Tables
                            </small>
                        </h1>
                    </div><!-- /.page-header -->

			<div class="row">
				<div class="col-xs-12">
					<!-- PAGE CONTENT BEGINS -->

					<div class="row">
						<div class="col-xs-12">



							<div class="row">
								<div class="col-xs-12">


									<div class="clearfix">
										<form name="search_form" method="post" action="#">
											<label class="col-xs-2">Select Department</label>
											<select id="searchby" name="searchby" class="form-control select2 col-xs-4" style="width: 20%;">
												<option selected="selected" style=" display: none;">--Select--</option>
												<option value="CS" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == 'CS')?'selected="selected"':''; ?>>CSE</option>
												<option value="EC" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == 'EC')?'selected="selected"':''; ?>>ECE</option>
												<option value="ME" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == 'ME')?'selected="selected"':''; ?>>MECH</option>
												<option value="CI" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == 'CI')?'selected="selected"':''; ?>>CIVIL</option>
												<option value="IT" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == 'IT')?'selected="selected"':''; ?>>IT</option>
												<option value="32J" <?php echo (!empty($_POST['searchby']) && $_POST['searchby'] == '32J')?'selected="selected"':''; ?>>MSC</option>
											</select>
											<button type="submit" id="submit" name="submit" style="margin-left:10px" class="btn btn-sm btn-primary"> Search </button></form>

										<div class="pull-right tableTools-container"></div>
									</div>

								</div></div>


							<section class="content">
								<div class="row">
									<div class="col-xs-12">
										<div class="box">
											<div class="box-header">
												<h3 class="box-title">Student Details</h3>
											</div>
											<!-- /.box-header -->
											<div class="box-body">
												<table id="dynamic-table" class="table table-striped table-bordered table-hover">
													<thead>
													<tr>


														<th>User name</th>
														<th>First name</th>
														<th class="hidden-480">
															<i class="ace-icon fa fa-phone bigger-110 hidden-480"></i>
															Phone</th>

														<th>
															<i class="ace-icon fa fa-envelope-o bigger-110 hidden-480"></i>
															Email
														</th>
														<th class="hidden-480">Is Mentor</th>

														<th>Actions</th>
													</tr>
													</thead>

													<tbody>


													<?php

													if(isset($_POST['submit']))
													{

														$selected_val = $_POST['searchby'];  // Storing Selected Value In Variable
														if($selected_val=="CS")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}
														if($selected_val=="32J")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}
														if($selected_val=="EC")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}
														if($selected_val=="ME")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}
														if($selected_val=="CE")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}
														if($selected_val=="IT")
														{
															$result = mysql_query(" SELECT id,username,firstname,phonenumber,email,IsMentor from cc_users where IsMentor='no' && username LIKE '%{$selected_val}%' ") or die(mysql_error());
														}

														while ($row = mysql_fetch_array($result)) {
															?>
															<tr>


																<td>
																	<?php echo $row['username'];?>
																</td>
																<td>
																	<?php echo $row['firstname'];?>
																</td>
																<td class="hidden-480">
																	<?php echo $row['phonenumber']; ?>
																</td>

																<td>
																	<?php echo $row['email'];?>
																</td>
																<td>
																	<?php echo $row['IsMentor'];?>
																</td>

																<!--</tr>	-->


																<!--	<td class="hidden-480">
                                                                        <span class="label label-sm label-warning">Expiring</span>
                                                                    </td>-->



																<td>
																	<div class="hidden-sm hidden-xs action-buttons">
								<?php	
								echo'	<a class="blue" href="Assign_Mentor.php?id='.$row['id'].'&username='.$row['username'].' " data-toggle="tooltip" title="Assign Mentor" onclick="clickAndDisable(this);">
								<i class="ace-icon fa  fa-exchange bigger-130"></i>
								</a>'
								?>	
												

																
														
															
															<?php
															echo'<a style="color:red" class="red" href="delete.php?id='.$row['id'].' " data-toggle="tooltip" title="Delete User">
																	<i class="ace-icon fa fa-trash-o bigger-130"></i>
																</a>'
															?>
															</div>

																	<div class="hidden-md hidden-lg">
																		<div class="inline pos-rel">
																			<button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
																				<i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
																			</button>

																			<ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">


																				<li>
																					<?php
																					echo'	<a class="blue" href="Assign_Mentor.php?id='.$row['id'].'&username='.$row['username'].' " data-toggle="tooltip" title="Assign Mentor" onclick="clickAndDisable(this);">
								<i class="ace-icon fa  fa-exchange bigger-130"></i>
								</a>'
																					?>
																				</li>


																				<li>

																					<?php
																					echo'<a class="red" href="delete.php?id='.$row['id'].' " data-toggle="tooltip" title="Delete User">
																	<i class="ace-icon fa fa-trash-o bigger-130"></i>
																</a>'
																					?>
																				</li>
																			</ul>
																		</div>
																	</div>
																</td>
															</tr>
														<?php  }  } ?>
													</tbody>
												</table>

											</div>
										</div>
									</div>
								</div>
							</section>
							<!--	<h4 class="pink">
                                <i class="ace-icon fa fa-hand-o-right icon-animated-hand-pointer blue"></i>
                                <a href="#modal-table" role="button" class="green" data-toggle="modal"> Table Inside a Modal Box </a>
                            </h4>-->

						</div>


					</div></div></div></div></div>

	<!-- jQuery 2.2.3 -->
	<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
	<!-- Bootstrap 3.3.6 -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<!-- DataTables -->
	<script src="assets/js/jquery.dataTables.min.js"></script>
	<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
	<script src="assets/js/dataTables.tableTools.min.js"></script>
	<script src="assets/js/dataTables.colVis.min.js"></script>
	<script src="datat.js"></script>
	<!-- SlimScroll -->
	<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
	<!-- FastClick -->
	<script src="plugins/fastclick/fastclick.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/app.min.js"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="dist/js/demo.js"></script>
	<!-- page script -->

	</form></div></div>
<?php include('footer.php'); ?>
</body>
</html>
