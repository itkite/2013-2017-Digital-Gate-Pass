<html>
<body>
<form method="post" action="send_mail.php">
Name:   <input type="text" name="tname">
Mobile No:  <input type="text" name="tmno">
Email ID  <input type="text" name="temailid">
  <input type="Submit" Value="Send Mail to Admin">
</form>
</body>
</html>