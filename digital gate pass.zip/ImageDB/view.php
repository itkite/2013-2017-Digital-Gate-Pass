<?php
mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db("imagestor") or die(mysql_error());

$id =addslashes($_REQUEST['id']);

$image =mysql_query("SELECT * FROM images WHERE id=$id");
//$image =mysql_query("SELECT * FROM images");
$imagee=mysql_fetch_assoc($image);
$image = $image['image'];

header("Content-type: image/jpeg");
echo $imagee['$image'];



?> 